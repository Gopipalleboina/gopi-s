export const RAPID_API_KEY = "8a9299f09bmsh709f976bc127e25p19c50ejsn721bc0e68849";
export const RAPID_API_HOST = "microsoft-translator-text.p.rapidapi.com";