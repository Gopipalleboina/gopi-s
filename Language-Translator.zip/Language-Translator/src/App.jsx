import Translator from './components/Translator'
import 'react-toastify/dist/ReactToastify.css';

function App() {

  return (
    <>
      <Translator />       
    </>
  )
}

export default App
